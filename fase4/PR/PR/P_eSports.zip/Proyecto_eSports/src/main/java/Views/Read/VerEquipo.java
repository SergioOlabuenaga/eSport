package Views.Read;

import Controlador.Main;

import javax.swing.*;

public class VerEquipo {
    public JPanel jVerEquipo;
    private JTextArea taEquipos;
    private JLabel jlEquipos;

    public VerEquipo() {
        taEquipos.setText(Main.consultarEquipos());
    }
}
