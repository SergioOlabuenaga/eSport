package Modelo;

import javax.persistence.*;
import java.sql.Date;
import java.util.Objects;

@Entity
@IdClass(PartidoPK.class)
public class Partido {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_PARTIDO")
    private int idPartido;
    @Basic
    @Column(name = "HORA")
    private Date hora;
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_LOCAL")
    private short idLocal;
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_VISITANTE")
    private short idVisitante;
    @Basic
    @Column(name = "PUNTOS_LOCAL")
    private Boolean puntosLocal;
    @Basic
    @Column(name = "PUNTOS_VISITANTE")
    private Boolean puntosVisitante;
    @Basic
    @Column(name = "ID_JORNADA")
    private short idJornada;

    public int getIdPartido() {
        return idPartido;
    }

    public void setIdPartido(int idPartido) {
        this.idPartido = idPartido;
    }

    public Date getHora() {
        return hora;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }

    public short getIdLocal() {
        return idLocal;
    }

    public void setIdLocal(short idLocal) {
        this.idLocal = idLocal;
    }

    public short getIdVisitante() {
        return idVisitante;
    }

    public void setIdVisitante(short idVisitante) {
        this.idVisitante = idVisitante;
    }

    public Boolean getPuntosLocal() {
        return puntosLocal;
    }

    public void setPuntosLocal(Boolean puntosLocal) {
        this.puntosLocal = puntosLocal;
    }

    public Boolean getPuntosVisitante() {
        return puntosVisitante;
    }

    public void setPuntosVisitante(Boolean puntosVisitante) {
        this.puntosVisitante = puntosVisitante;
    }

    public short getIdJornada() {
        return idJornada;
    }

    public void setIdJornada(short idJornada) {
        this.idJornada = idJornada;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Partido partido = (Partido) o;
        return idPartido == partido.idPartido && idLocal == partido.idLocal && idVisitante == partido.idVisitante && idJornada == partido.idJornada && Objects.equals(hora, partido.hora) && Objects.equals(puntosLocal, partido.puntosLocal) && Objects.equals(puntosVisitante, partido.puntosVisitante);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPartido, hora, idLocal, idVisitante, puntosLocal, puntosVisitante, idJornada);
    }
}
