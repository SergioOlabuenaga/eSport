package Modelo;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Jugador {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_JUGADOR")
    private int idJugador;
    @Basic
    @Column(name = "ID_EQUIPO")
    private int idEquipo;
    @Basic
    @Column(name = "NOMBRE")
    private String nombre;
    @Basic
    @Column(name = "NICKNAME")
    private String nickname;
    @Basic
    @Column(name = "SUELDO")
    private int sueldo;
    @Basic
    @Column(name = "TELEFONO")
    private String telefono;
    @Basic
    @Column(name = "ROL")
    private String rol;


    public int getIdJugador() {
        return idJugador;
    }

    public void setIdJugador(int idJugador) {
        this.idJugador = idJugador;
    }

    public int getIdEquipo() {
        return idEquipo;
    }

    public void setIdEquipo(int idEquipo) {
        this.idEquipo = idEquipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Jugador jugador = (Jugador) o;
        return idJugador == jugador.idJugador && sueldo == jugador.sueldo && Objects.equals(idEquipo, jugador.idEquipo) && Objects.equals(nombre, jugador.nombre) && Objects.equals(nickname, jugador.nickname) && Objects.equals(telefono, jugador.telefono) && Objects.equals(rol, jugador.rol);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idJugador, idEquipo, nombre, nickname, sueldo, telefono, rol);
    }

    @Override
    public String toString() {
        return nickname;
    }
}
