package Modelo;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Equipo {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_EQUIPO")
    private int idEquipo;
    @Basic
    @Column(name = "NOMBRE")
    private String nombre;
    @Basic
    @Column(name = "ANO_CREACION")
    private int anoCreacion;
    @Basic
    @Column(name = "NACIONALIDAD")
    private String nacionalidad;
    @Basic
    @Column(name = "ID_DUENO")
    private int idDueno;
    @Basic
    @Column(name = "ID_ENTRENADOR")
    private int idEntrenador;
    @Basic
    @Column(name = "ID_ASISTENTE")
    private int idAsistente;

    public int getIdEquipo() {
        return idEquipo;
    }

    public void setIdEquipo(int idEquipo) {
        this.idEquipo = idEquipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAnoCreacion() {
        return anoCreacion;
    }

    public void setAnoCreacion(int anoCreacion) {
        this.anoCreacion = anoCreacion;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public int getIdDueno() {
        return idDueno;
    }

    public void setIdDueno(int idDueno) {
        this.idDueno = idDueno;
    }

    public int getIdEntrenador() {
        return idEntrenador;
    }

    public void setIdEntrenador(int idEntrenador) {
        this.idEntrenador = idEntrenador;
    }

    public int getIdAsistente() {
        return idAsistente;
    }

    public void setIdAsistente(int idAsistente) {
        this.idAsistente = idAsistente;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Equipo equipo = (Equipo) o;
        return idEquipo == equipo.idEquipo && anoCreacion == equipo.anoCreacion && idDueno == equipo.idDueno && idEntrenador == equipo.idEntrenador && Objects.equals(nombre, equipo.nombre) && Objects.equals(nacionalidad, equipo.nacionalidad) && Objects.equals(idAsistente, equipo.idAsistente);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEquipo, nombre, anoCreacion, nacionalidad, idDueno, idEntrenador, idAsistente);
    }

    @Override
    public String toString() {
        return nombre;
    }
}
