package Modelo;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Dueno {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_DUENO")
    private int idDueno;
    @Basic
    @Column(name = "NOMBRE")
    private String nombre;
    @Basic
    @Column(name = "TELEFONO")
    private String telefono;
    @Basic
    @Column(name = "NOMBRE_EMPRESA")
    private String nombreEmpresa;

    public int getIdDueno() {
        return idDueno;
    }

    public void setIdDueno(int idDueno) {
        this.idDueno = idDueno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dueno dueno = (Dueno) o;
        return idDueno == dueno.idDueno && Objects.equals(nombre, dueno.nombre) && Objects.equals(telefono, dueno.telefono) && Objects.equals(nombreEmpresa, dueno.nombreEmpresa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idDueno, nombre, telefono, nombreEmpresa);
    }

    @Override
    public String toString() {
        return nombre;
    }
}
