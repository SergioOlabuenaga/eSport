package Views.Delete;

import Controlador.Main;
import Modelo.Asistente;
import Modelo.Equipo;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class BorrarAsistente {
    public JPanel jBorrarAsistente;
    private JButton bAceptar;
    private JButton bSalir;
    private JLabel jlTitulo;
    private JPanel jBotones;
    private JPanel jContenido;
    private JLabel jlNombre;
    private JComboBox cbAsistente;

    public BorrarAsistente() {

        ArrayList<Asistente> Asistente = Main.verNombreAsistentes();
        for (Asistente asis : Asistente) {
            cbAsistente.addItem(asis);
        }

        bAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.borrarAsistente(cbAsistente.getSelectedItem());
                Main.cerrarVentana();
                Main.ventanaEliminarAsistente();
            }
        });
        bSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.cerrarVentana();
                Main.ventanaAdministrador();
            }
        });
    }
}
