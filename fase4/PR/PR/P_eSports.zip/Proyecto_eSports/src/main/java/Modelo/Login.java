package Modelo;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Login {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_LOGIN")
    private int idLogin;
    @Basic
    @Column(name = "USUARIO")
    private String usuario;
    @Basic
    @Column(name = "PASS")
    private String pass;
    @Basic
    @Column(name = "TIPO")
    private String tipo;

    public int getIdLogin() {
        return idLogin;
    }

    public void setIdLogin(int idLogin) {
        this.idLogin = idLogin;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Login login = (Login) o;
        return idLogin == login.idLogin && Objects.equals(usuario, login.usuario) && Objects.equals(pass, login.pass) && Objects.equals(tipo, login.tipo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLogin, usuario, pass, tipo);
    }

    @Override
    public String toString() {
        return usuario;
    }
}
