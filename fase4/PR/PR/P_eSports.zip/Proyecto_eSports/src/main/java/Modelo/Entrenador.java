package Modelo;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Entrenador {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_ENTRENADOR")
    private int idEntrenador;
    @Basic
    @Column(name = "NOMBRE")
    private String nombre;
    @Basic
    @Column(name = "TELEFONO")
    private String telefono;
    @Basic
    @Column(name = "ANOS_EXP")
    private int anosExp;

    public int getIdEntrenador() {
        return idEntrenador;
    }

    public void setIdEntrenador(int idEntrenador) {
        this.idEntrenador = idEntrenador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getAnosExp() {
        return anosExp;
    }

    public void setAnosExp(int anosExp) {
        this.anosExp = anosExp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Entrenador that = (Entrenador) o;
        return idEntrenador == that.idEntrenador && Objects.equals(nombre, that.nombre) && Objects.equals(telefono, that.telefono) && Objects.equals(anosExp, that.anosExp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEntrenador, nombre, telefono, anosExp);
    }

    @Override
    public String toString() {
        return nombre;
    }
}
