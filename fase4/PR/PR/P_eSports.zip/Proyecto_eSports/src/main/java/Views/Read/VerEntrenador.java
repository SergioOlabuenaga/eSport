package Views.Read;

import Controlador.Main;

import javax.swing.*;

public class VerEntrenador {
    public JPanel jVerEntrenador;
    private JLabel jlEntrenador;
    private JTextArea taEntrenadores;

    public VerEntrenador(){
        taEntrenadores.setText(Main.consultarEntrenadores());
    }

}
