package Controlador;
import Modelo.*;
import Views.Create.*;
import Views.Delete.*;
import Views.Login.*;
import Views.Read.*;
import Views.Update.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    static JFrame frame;
    public static String usuario;
    public static String nombre;
    public static String tipoUsuario;

    public static void main (String[] args) {
        ventanaPrincipal();
}

    public static Connection conectarbbdd() {
        Connection con = null;
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            String conexion = "jdbc:oracle:thin:@SrvOracle:1521:orcl";
            con = DriverManager.getConnection(conexion,"eqdaw04","eqdaw04");
        }
        catch (Exception e) {
            System.err.println("Error: "+ e.getMessage());
        }
        return con;
    }

    public static boolean login(String pass) {
        boolean error = true;
        usuario = usuario.toLowerCase();
        try {
            String select = "SELECT TIPO FROM LOGIN WHERE LOWER(USUARIO) ='" + usuario + "' AND PASS ='" + pass + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            resultado.next();
            tipoUsuario = resultado.getString("tipo").toLowerCase();
            if (resultado.getString("tipo").toLowerCase().equals("u")) {
                ocultarVentana();
                ventanaUsuario();
            } else if (resultado.getString("tipo").toLowerCase().equals("a")) {
                ocultarVentana();
                ventanaAdministrador();
            } else {
                error = false;
            }
        } catch (Exception e){
            error = false;
        }
        return error;
    }

    // Metodos cerrar/ocultar ventanas
    public static void cerrarVentana() {
        frame.dispose();
    }
    public static void ocultarVentana() {
        frame.setVisible(false);
    }

    // Métodos de Vistas Principales
    public static void ventanaPrincipal() {
        frame = new JFrame("Inicio de sesión");
        frame.setContentPane(new VistaPrincipal().jPrincipal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    public static void ventanaUsuario(){
        frame = new JFrame("Vista de usuario");
        frame.setContentPane(new VistaUsuario().jVistaUsuario);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    public static void ventanaAdministrador(){
        frame = new JFrame("Vista de administrador");
        frame.setContentPane(new VistaAdministrador().jAdministrador);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // Ventanas Crear
    public static void ventanaCrearUsuario(){
        frame = new JFrame("Crear usuario");
        frame.setContentPane(new CrearUsuario().jCrearUsuario);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }
    public static void ventanaCrearEquipo(){
        frame = new JFrame("Crear equipo");
        frame.setContentPane(new CrearEquipo().jCrearEquipo);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }
    public static void ventanaCrearDueño(){
        frame = new JFrame("CrearDueño");
        frame.setContentPane(new CrearDueño().jCrearDueño);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }
    public static void ventanaCrearJugador(){
        frame = new JFrame("Crear jugador");
        frame.setContentPane(new CrearJugador().jJugador);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }
    public static void ventanaCrearAsistente(){
        frame = new JFrame("Crear Asistente");
        frame.setContentPane(new CrearAsistente().jCrearAsistente);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }
    public static void ventanaCrearEntrenador() {
        frame = new JFrame("Crear Entrenador");
        frame.setContentPane(new CrearEntrenador().jCrearEntrenador);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }
    // Ventanas Visualizar
    public static void ventanaVerUsuarios() {
        frame = new JFrame("Lista de usuarios");
        frame.setContentPane(new VerUsuario().jVerUsuarios);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaVerJugadores() {
        frame = new JFrame("Visualización de jugadores");
        frame.setContentPane(new VerJugador().jVerJugadores);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaVerDueno() {
        frame = new JFrame("Ver Dueño");
        frame.setContentPane(new VerDueño().jVerDueño);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaVerAsistente() {
        frame = new JFrame("Ver Asistente");
        frame.setContentPane(new VerAsistente().jVerAsistente);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaVerEntrenador() {
        frame = new JFrame("Ver Entrenador");
        frame.setContentPane(new VerEntrenador().jVerEntrenador);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaVerEquipo() {
        frame = new JFrame("Ver Equipo");
        frame.setContentPane(new VerEquipo().jVerEquipo);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }


    public static void ventanaVerJornada() {
        frame = new JFrame("Ver Jornadas");
        frame.setContentPane(new VerJornada().jVerJornadas);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaVerClasificacion(){
        frame = new JFrame("Ver Clasificacion");
        frame.setContentPane(new VerClasificacion().jVerClasificacion);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    // Ventana Modificar
    public static void ventanaModificarAsistente() {
        frame = new JFrame("Modificar Asistente");
        frame.setContentPane(new ModificarAsistente().jModificarAsistente);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaModificarDueño() {
        frame = new JFrame("Modificar Dueño");
        frame.setContentPane(new ModificarDueño().jModificarDueño);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaModificarEntrenador() {
        frame = new JFrame("Modificar Entrenador");
        frame.setContentPane(new ModificarEntrenador().jModificarEntrenador);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaModificarEquipo() {
        frame = new JFrame("Modificar Equipo");
        frame.setContentPane(new ModificarEquipo().jModificarEquipo);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaModificarJugador() {
        frame = new JFrame("Modificar Jugador");
        frame.setContentPane(new ModificarJugador().jModificarJugador);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaModificarUsuario() {
        frame = new JFrame("Modificar Usuario");
        frame.setContentPane(new ModificarUsuario().jModificarUsuario);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaModificarJornada() {

    }


    // Ventanas Eliminar
    public static void ventanaEliminarUsuario() {
        frame = new JFrame("Eliminar Usuario");
        frame.setContentPane(new BorrarUsuario().jEliminarUsuario);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaEliminarEquipo() {
        frame = new JFrame("Borrar Equipo");
        frame.setContentPane(new BorrarEquipo().jEliminarEquipo);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaEliminarJugador() {
        frame = new JFrame("Borrar Jugador");
        frame.setContentPane(new BorrarJugador().jBorrarJugador);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaEliminarDueño() {
        frame = new JFrame("Borrar Dueño");
        frame.setContentPane(new BorrarDueño().jBorrarDueño);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaEliminarEntrenador() {
        frame = new JFrame("Borrar Entrenador");
        frame.setContentPane(new BorrarEntrenador().jBorrarEntrenador);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }

    public static void ventanaEliminarAsistente() {
        frame = new JFrame("Borrar Asistente");
        frame.setContentPane(new BorrarAsistente().jBorrarAsistente);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
                ventanaAdministrador();
            }
        });
    }



    // Metodos generar datos
    public static void generarUsuario(String nombre, String pass) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        Login log = new Login();
        log.setUsuario(nombre);
        log.setPass(pass);
        log.setTipo("U");
        em.persist(log);
        transaction.commit();
    }

    public static void generarDueño(String nombre, String telefono, String empresa) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            do {
                transaction.begin();
                Dueno dueno = new Dueno();
                dueno.setNombre(nombre);
                dueno.setTelefono(telefono);
                dueno.setNombreEmpresa(empresa);
                em.persist(dueno);
                transaction.commit();
            } while (JOptionPane.showConfirmDialog(null, "¿Desea crear mas dueños?", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error desconocido. Contacte con un administrador");
        }
    }

    public static void generarJugador(int idEquipo, String nombre, String nickname, String sueldo, String telefono, String
            rol) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();

        // Conseguir id_equipo a traves de nombre equipo
        try {
            do {
                transaction.begin();
                Jugador jug = new Jugador();
                jug.setIdEquipo(idEquipo);
                jug.setNombre(nombre);
                jug.setNickname(nickname);
                jug.setSueldo(Integer.parseInt(sueldo));
                jug.setTelefono(telefono);
                jug.setRol(rol);
                em.persist(jug);
                transaction.commit();
            } while (JOptionPane.showConfirmDialog(null, "¿Desea crear mas jugadores?", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en la BBDD: " + e.getMessage());
        }
    }

    public static void generarEntrenador(String nombre, String telefono, int añosExp) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            do {
                transaction.begin();
                Entrenador ent = new Entrenador();
                ent.setNombre(nombre);
                ent.setTelefono(telefono);
                ent.setAnosExp(añosExp);
                em.persist(ent);
                transaction.commit();
            } while (JOptionPane.showConfirmDialog(null, "¿Desea crear mas entrenadores?", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error desconocido. Contacte con un administrador");
        }
    }

    public static void generarAsistente(String nombre, String tlf, String desc) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            do {
                transaction.begin();
                Asistente a = new Asistente();
                a.setNombre(nombre);
                a.setTelefono(tlf);
                a.setDescripcionFuncion(desc);
                em.persist(a);
                transaction.commit();
            } while (JOptionPane.showConfirmDialog(null, "¿Desea crear mas asistentes?", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error desconocido. Contacte con un administrador");
        }
    }

    public static void generarEquipo(String nombre, String anoCrear, String nacionalidad, Dueno id_dueno, Entrenador id_entrenador,
                                     Asistente id_asistentes) {
        int anoCreacion = Integer.parseInt(anoCrear);
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            transaction.begin();
            Equipo equi = new Equipo();
            equi.setNombre(nombre);
            equi.setAnoCreacion(anoCreacion);
            equi.setNacionalidad(nacionalidad);
            equi.setIdDueno(id_dueno.getIdDueno());
            equi.setIdEntrenador(id_entrenador.getIdEntrenador());
            System.out.println(id_asistentes.getIdAsistente());
            equi.setIdAsistente(id_asistentes.getIdAsistente());
            em.persist(equi);
            transaction.commit();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error desconocido. Contacte con un administrador");
        }
    }

    public static void generarEquipo (String nombre, String anoCrear, String nacionalidad, Dueno id_dueno, Entrenador id_entrenador) {
        int anoCreacion = Integer.parseInt(anoCrear);
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            do {
                transaction.begin();
                Equipo equi = new Equipo();
                equi.setNombre(nombre);
                equi.setAnoCreacion(anoCreacion);
                equi.setNacionalidad(nacionalidad);
                equi.setIdDueno(id_dueno.getIdDueno());
                equi.setIdEntrenador(id_entrenador.getIdEntrenador());
                em.persist(equi);
                transaction.commit();
            } while (JOptionPane.showConfirmDialog(null, "¿Desea crear mas equipos?", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error desconocido. Contacte con un administrador");
        }
    }

    public static void generarJornada() {
        int dia = 01;
        int mes = 01;
        int equipos = 0;
        int x = 0;
        try {
            String selectID = "SELECT COUNT(*)-1 FROM EQUIPO";
            PreparedStatement ps = conectarbbdd().prepareStatement(selectID);
            ResultSet resultadoID = ps.executeQuery(selectID);
            while (resultadoID.next()) {
                equipos = resultadoID.getInt("COUNT(*)-1");
            }

            do {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
                String fecha = "2022/" + mes + "/" + dia;
                // Date fechaBuena = (Date) sdf.parse(fecha);

                /* Posibles soluciones Error: java.util.Date cannot be cast to java.sql.Date
                java.util.Date dateUtil = new java.util.Date(fecha);
                java.sql.Date dateSql= new java.sql.Date(dateUtil.getYear(),dateUtil.getMonth(),dateUtil.getDay());
                */

                EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
                EntityManager em = emf.createEntityManager();
                EntityTransaction transaction = em.getTransaction();

                if (dia < 28) {
                    String insertar = "INSERT INTO JORNADA(FECHA) VALUES(TO_DATE('" + fecha + "','yyyy/MM/dd'))";
                    PreparedStatement ps2 = conectarbbdd().prepareStatement(insertar);
                    ResultSet resultado = ps2.executeQuery(insertar);

                    /* Me da fallos, lo he hecho con la manera de arriba
                    transaction.begin();
                    Jornada jor = new Jornada();
                    jor.setFecha(Date.valueOf(fechaBuena.toLocalDate()));
                    em.persist(jor);
                    transaction.commit(); */
                    dia = dia + 07;
                    x ++;
                } else {
                    mes = mes + 01;
                    dia = 01;
                }
            } while (equipos > x);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Metodos borrar datos
    public static void borrarUsuario(Object usu){
        try {
            String borrar = "DELETE FROM LOGIN WHERE LOWER(usuario) = '" + usu.toString().toLowerCase() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(borrar);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(borrar);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Usuario borrado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }

    }

    public static void borrarEquipo(Object equi) {
        try {
            String borrar = "DELETE FROM EQUIPO WHERE LOWER(NOMBRE) = '" + equi.toString().toLowerCase() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(borrar);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(borrar);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Equipo borrado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }

    public static void borrarDueño(Object due) {
        try {
            String borrar = "DELETE FROM DUENO WHERE NOMBRE = '" + due.toString() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(borrar);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(borrar);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Dueno borrado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }

    public static void borrarJugador(Object jug) {
        try {
            String borrar = "DELETE FROM JUGADOR WHERE lower(NICKNAME) = '" + jug.toString().toLowerCase() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(borrar);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(borrar);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Jugador borrado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }

    public static void borrarEntrenador(Object ent) {
        try {
            String borrar = "DELETE FROM ENTRENADOR WHERE lower(nombre) = '" + ent.toString().toLowerCase() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(borrar);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(borrar);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Jugador borrado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }

    public static void borrarAsistente(Object asis) {
        try {
            String borrar = "DELETE FROM ASISTENTE WHERE nombre = '" + asis.toString() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(borrar);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(borrar);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Asistente borrado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }

    // Metodos visualizar datos
    public static String consultarUsuarios() {
        StringBuilder datos = new StringBuilder("");
        try {
            String select = "SELECT ID_LOGIN, USUARIO, PASS FROM LOGIN WHERE TIPO = 'U' ORDER BY ID_LOGIN ASC";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                datos.append("  ID_Usuario = ").append(resultado.getInt("id_login")).append(", Usuario = ").
                        append(resultado.getString("usuario")).append(", Contraseña = ")
                        .append(resultado.getString("pass")).append("\n");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
        return datos.toString();
    }

    public static String consultarDueno() {
        StringBuilder datos = new StringBuilder("");
        try {
            String select = "SELECT NOMBRE, TELEFONO, NOMBRE_EMPRESA FROM DUENO ORDER BY ID_DUENO ASC";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                datos.append("  Nombre = ").append(resultado.getString("nombre")).append(", Teléfono = ").
                        append(resultado.getString("telefono")).append(", Nombre de la empresa = ")
                        .append(resultado.getString("nombre_empresa")).append("\n");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
        return datos.toString();
    }

    public static String consultarClasificacion() {
        StringBuilder datos = new StringBuilder("");
        try {
            String select = "SELECT NOMBRE, PUNTOS FROM VerClasificacion";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                datos.append("  Equipo = ").append(resultado.getString("nombre")).append(", Puntos = ").
                        append(resultado.getString("puntos")).append("\n");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
        return datos.toString();
    }



    public static String consultarEntrenadores() {
        StringBuilder datos = new StringBuilder("");
        try {
            String select = "SELECT NOMBRE, TELEFONO, ANOS_EXP FROM ENTRENADOR ORDER BY ID_ENTRENADOR ASC";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                datos.append("  Nombre = ").append(resultado.getString("nombre")).append(", Teléfono = ").
                        append(resultado.getString("telefono")).append(", Años de experiencia = ")
                        .append(resultado.getInt("anos_exp")).append("\n");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
        return datos.toString();
    }

    public static String consultarAsistente() {
        StringBuilder datos = new StringBuilder("");
        try {
            String select = "SELECT NOMBRE, TELEFONO, DESCRIPCION_FUNCION FROM ASISTENTE ORDER BY ID_ASISTENTE ASC";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                datos.append("  Nombre = ").append(resultado.getString("nombre")).append(", Teléfono = ").
                        append(resultado.getString("telefono")).append(", Función = ")
                        .append(resultado.getString("descripcion_funcion")).append("\n");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
        return datos.toString();
    }

    public static String consultarEquipos() {
        StringBuilder datos = new StringBuilder("");
        try {
            String select = "SELECT * FROM VerEquipos";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                datos.append("  Equipo = ").append(resultado.getString("nombre")).append(", Año creación = ").
                        append(resultado.getString("año")).append(", Nacionalidad = ")
                        .append(resultado.getString("nacionalidad")).append(", Dueño = ")
                        .append(resultado.getString("dueno")).append(", Asistente = ")
                        .append(resultado.getString("asistente")).append(", Entrenador = ")
                        .append(resultado.getString("entrenador")).append("\n");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
        return datos.toString();
    }

    public static String consultarJugadores(Equipo Equipo) {
        String datosJugadores = "";
        try {
            int idEquipo = 0;
            String selectID = "SELECT ID_EQUIPO FROM EQUIPO WHERE NOMBRE = '" + Equipo.getNombre() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(selectID);
            ResultSet resultadoID = ps.executeQuery(selectID);
            while (resultadoID.next()) {
                idEquipo = resultadoID.getInt("id_equipo");
            }
            String select = "SELECT NOMBRE, NICKNAME, SUELDO, TELEFONO, ROL FROM JUGADOR WHERE ID_EQUIPO = '" + idEquipo
                    + "'";
            PreparedStatement ps2 = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps2.executeQuery(select);
            while (resultado.next()) {
                datosJugadores = datosJugadores + "  Nombre = " + resultado.getString("NOMBRE") +
                        ", Nickname: " + resultado.getString("NICKNAME") +
                        ", Sueldo: " + resultado.getInt("SUELDO") +
                        ", Teléfono: " + resultado.getString("TELEFONO") +
                        ", Rol: " + resultado.getString("ROL") + "\n";
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return datosJugadores;
    }

    public static String consultarJornadas(){
        StringBuilder datos = new StringBuilder("");
        try {
            String select = "SELECT ID_JORNADA, FECHA FROM JORNADA";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                datos.append("  Nº de Jornada = ").append(resultado.getInt("id_jornada")).append(", Fecha correspondiente = ").
                        append(resultado.getDate("fecha")).append("\n");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
        return datos.toString();
    }

    //Metedos actualizar datos

    public static void actializarDueno (Object nom, String tlf, String nEmpresa){
        try{
        String modifica = "UPDATE DUENO SET TELEFONO = '" + tlf +"', NOMBRE_EMPRESA= '" +nEmpresa +"' WHERE NOMBRE = '" + nom.toString() +"'";
        PreparedStatement ps = conectarbbdd().prepareStatement(modifica);
        if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                        " es irreversible", "Confirmación",
                JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
            ResultSet resultado = ps.executeQuery(modifica);
            resultado.next();
            JOptionPane.showMessageDialog(null, "Dueño modificado correctamente");
        }
    } catch (Exception e) {
        System.out.println(e.getClass());
    }

    }
    public static void actializarEntrenadores(Object nom, String tlf,int añosExp){
        try{
            String modifica = "UPDATE ENTRENADOR SET TELEFONO = '" + tlf +"', ANOS_EXP= '" +añosExp +"' WHERE NOMBRE = '" + nom.toString() +"'";
            PreparedStatement ps = conectarbbdd().prepareStatement(modifica);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(modifica);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Entrenador modificado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }


    }
    public static void actializarAsistente(Object nom, String tlf, String descrip){
        try {
            String modifica = "UPDATE ASISTENTE SET TELEFONO = '" + tlf +"', DESCRIPCION_FUNCION = '" +descrip
                    +"' WHERE NOMBRE = '" + nom.toString() +"'";
            PreparedStatement ps = conectarbbdd().prepareStatement(modifica);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(modifica);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Asistente modificado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }
    public static void actializarUsuario(Object nom, String contraseña){
        try {
            String modifica = "UPDATE LOGIN SET PASS = '" + contraseña + "' WHERE USUARIO = '" + nom.toString() +"'";
            PreparedStatement ps = conectarbbdd().prepareStatement(modifica);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(modifica);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Usuario modificado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }
    public static void actializarEquipos (Object nom, String aCrear, String nacion, Object dueno, Object entre, Object asisten){
        try {
            Dueno due = new Dueno();
            due.setNombre(dueno.toString());
            int idDueno = obtenerIdDueno(due);

            Entrenador ent = new Entrenador();
            ent.setNombre(entre.toString());
            int idEntrenador = obtenerIdEntrenador(ent);

            Asistente asis = new Asistente();
            asis.setNombre(asisten.toString());
            int idAsistente = obtenerIdAsistente(asis);

            int año = Integer.parseInt(aCrear);
            String modifica = "UPDATE EQUIPO SET ANO_CREACION= '" + año +"', NACIONALIDAD = '" + nacion +"', ID_DUENO = '"+
                    idDueno +"', ID_ENTRENADOR= '"+ idEntrenador +"', ID_ASISTENTE= '"+idAsistente +"' WHERE NOMBRE = '" + nom.toString() +"'";
            PreparedStatement ps = conectarbbdd().prepareStatement(modifica);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(modifica);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Equipo modificado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }
    public static void actializarJugadores(Object nick, String nom, String sueldo, String rol, String tlf, Object equipo ){
        try {
            Equipo equi = new Equipo();
            equi.setNombre(equipo.toString());
            int idEquipo = obtenerIdEquipo(equi);


            String modifica = "UPDATE JUGADOR SET NOMBRE = '" + nom + "', SUELDO = '" + sueldo +"', TELEFONO = '" + tlf +"', ROL = '"+
                    rol +"', ID_EQUIPO= '"+idEquipo +"' WHERE NICKNAME = '" + nick.toString() +"'";
            PreparedStatement ps = conectarbbdd().prepareStatement(modifica);
            if (JOptionPane.showConfirmDialog(null, "¿Estás seguro? Esta acción" +
                            " es irreversible", "Confirmación",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null) == 0) {
                ResultSet resultado = ps.executeQuery(modifica);
                resultado.next();
                JOptionPane.showMessageDialog(null, "Jugador modificado correctamente");
            }
        } catch (Exception e) {
            System.out.println(e.getClass());
        }
    }
    public static void actializarJornada (){}




    // Metodos internos necesarios
    public static ArrayList<Equipo> verNombreEquipos() {
        ArrayList<Equipo> listaEquipos = new ArrayList<>();
        try {
            String select = "SELECT NOMBRE FROM EQUIPO";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                Equipo e = new Equipo();
                e.setNombre(resultado.getString("nombre"));
                listaEquipos.add(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listaEquipos;
    }

    public static ArrayList<Dueno> verNombreDuenos() {
        ArrayList<Dueno> listaDuenos = new ArrayList<>();
        try {
            String select = "SELECT ID_DUENO, NOMBRE FROM DUENO WHERE ID_DUENO NOT IN (SELECT ID_DUENO FROM EQUIPO)";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                Dueno d = new Dueno();
                d.setNombre(resultado.getString("nombre"));
                d.setIdDueno(resultado.getInt("id_dueno"));
                listaDuenos.add(d);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listaDuenos;
    }

    public static ArrayList<Jugador> verNombreJugadores() {
        ArrayList<Jugador> listaJugador = new ArrayList<>();
        try {
            String select = "SELECT ID_JUGADOR, NICKNAME FROM JUGADOR";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                Jugador d = new Jugador();
                d.setNickname(resultado.getString("nickname"));
                d.setIdJugador(resultado.getInt("id_jugador"));
                listaJugador.add(d);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listaJugador;
    }

    public static ArrayList<Asistente> verNombreAsistentes() {
        ArrayList<Asistente> listaAsistentes = new ArrayList<>();
        try {
            String select = "SELECT ID_ASISTENTE, NOMBRE FROM ASISTENTE WHERE ID_ASISTENTE NOT IN (SELECT ID_ENTRENADOR FROM EQUIPO)";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                Asistente a = new Asistente();
                a.setNombre(resultado.getString("nombre"));
                a.setIdAsistente(resultado.getInt("id_asistente"));
                listaAsistentes.add(a);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listaAsistentes;
    }

    public static ArrayList<Entrenador> verNombreEntrenadores() {
        ArrayList<Entrenador> listaEntrenadores = new ArrayList<>();
        try {
            String select = "SELECT ID_ENTRENADOR, NOMBRE FROM ENTRENADOR WHERE ID_ENTRENADOR NOT IN " +
                    "(SELECT ID_ENTRENADOR FROM EQUIPO)";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                Entrenador e = new Entrenador();
                e.setNombre(resultado.getString("nombre"));
                e.setIdEntrenador(resultado.getInt("id_entrenador"));
                listaEntrenadores.add(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listaEntrenadores;
    }

    public static ArrayList<Login> verNombreUsuarios() {
        ArrayList<Login> listaUsuarios = new ArrayList<>();
        try {
            String select = "SELECT USUARIO FROM LOGIN WHERE TIPO = 'U'";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                Login l = new Login();
                l.setUsuario(resultado.getString("usuario"));
                listaUsuarios.add(l);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listaUsuarios;
    }

    public static int obtenerIdEquipo(Equipo team) {
        int id = -1;
        try {
            String selectID = "SELECT ID_EQUIPO FROM EQUIPO WHERE NOMBRE = '" + team.getNombre() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(selectID);
            ResultSet resultadoID = ps.executeQuery(selectID);
            while (resultadoID.next()) {
                id = resultadoID.getInt("id_equipo");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return id;
    }

    public static int obtenerIdEntrenador(Entrenador entrena) {
        int id = -1;
        try {
            String selectID = "SELECT ID_ENTRENADOR FROM ENTRENADOR WHERE NOMBRE = '" + entrena.getNombre() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(selectID);
            ResultSet resultadoID = ps.executeQuery(selectID);
            while (resultadoID.next()) {
                id = resultadoID.getInt("id_entrenador");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return id;
    }

    public static int obtenerIdAsistente(Asistente asiste) {
        int id = -1;
        try {
            String selectID = "SELECT ID_ASISTENTE FROM ASISTENTE WHERE NOMBRE = '" + asiste.getNombre() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(selectID);
            ResultSet resultadoID = ps.executeQuery(selectID);
            while (resultadoID.next()) {
                id = resultadoID.getInt("id_asistente");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return id;
    }

    public static int obtenerIdDueno(Dueno due) {
        int id = -1;
        try {
            String selectID = "SELECT ID_DUENO FROM DUENO WHERE NOMBRE = '" + due.getNombre() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(selectID);
            ResultSet resultadoID = ps.executeQuery(selectID);
            while (resultadoID.next()) {
                id = resultadoID.getInt("id_dueno");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return id;
    }

    public static Jugador infoJugadores(Object jug){
        Jugador juga = new Jugador();
        try {
            String select = "SELECT NOMBRE, SUELDO, TELEFONO, ROL FROM JUGADOR WHERE NICKNAME = '" + jug.toString() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                juga.setNombre(resultado.getString("nombre"));
                juga.setTelefono(resultado.getString("telefono"));
                juga.setSueldo(resultado.getInt("sueldo"));
                juga.setRol(resultado.getString("rol"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return juga;
    }

    public static Entrenador infoEntrenadores(Object entre){
        Entrenador entrena = new Entrenador();
        try {
            String select = "SELECT TELEFONO, ANOS_EXP FROM ENTRENADOR WHERE NOMBRE = '" + entre.toString() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                entrena.setTelefono(resultado.getString("telefono"));
                entrena.setAnosExp(resultado.getInt("anos_exp"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return entrena;
    }

    public static Dueno infoDueno(Object due){
        Dueno dueno = new Dueno();
        try {
            String select = "SELECT TELEFONO, NOMBRE_EMPRESA FROM DUENO WHERE NOMBRE = '" + due.toString() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                dueno.setTelefono(resultado.getString("telefono"));
                dueno.setNombreEmpresa(resultado.getString("nombre_empresa"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return dueno;
    }

    public static Asistente infoAsistente(Object asis){
        Asistente asistente = new Asistente();
        try {
            String select = "SELECT TELEFONO, DESCRIPCION_FUNCION FROM ASISTENTE WHERE NOMBRE = '" + asis.toString() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                asistente.setTelefono(resultado.getString("telefono"));
                asistente.setDescripcionFuncion(resultado.getString("descripcion_funcion"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return asistente;
    }

    public static Equipo infoEquipo(Object equi){
        Equipo equipo = new Equipo();
    try {
            String select = "SELECT ANO_CREACION, NACIONALIDAD FROM EQUIPO WHERE" +
                    " NOMBRE = '" + equi.toString() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                equipo.setAnoCreacion(resultado.getInt("ano_creacion"));
                equipo.setNacionalidad(resultado.getString("nacionalidad"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return equipo;
    }

    public static Login infoUsuario(Object usu){
        Login usuario = new Login();
        try {
            String select = "SELECT PASS FROM LOGIN WHERE USUARIO = '" + usu.toString() + "'";
            PreparedStatement ps = conectarbbdd().prepareStatement(select);
            ResultSet resultado = ps.executeQuery(select);
            while (resultado.next()) {
                usuario.setPass(resultado.getString("pass"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return usuario;
    }

    public static boolean validarTelefono(String tlf) {
        boolean error;
        Pattern pat = Pattern.compile("^[67]\\d{8}$");
        Matcher mat = pat.matcher(tlf);
        if (mat.matches()) {
            error = true;
        } else {
            JOptionPane.showMessageDialog(null, "Error: Introduzca un número de telefono valido");
            error = false;
        }
        return error;
    }

    public boolean validarAñoExp(String añoExp) {
        boolean error;
        Pattern pat = Pattern.compile("^[0-9]{2}$");
        Matcher mat = pat.matcher(añoExp);
        if (mat.matches()) {
            error = true;
        } else {
            JOptionPane.showMessageDialog(null, "Error: Introduzca un dato valido");
            error = false;
        }
        return error;
    }
}