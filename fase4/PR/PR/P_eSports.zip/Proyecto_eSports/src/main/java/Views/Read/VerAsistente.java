package Views.Read;

import Controlador.Main;

import javax.swing.*;

public class VerAsistente {
    public JPanel jVerAsistente;
    private JLabel jlTitulo;
    private JTextArea taAsistentes;

    public VerAsistente(){
        taAsistentes.setText(Main.consultarAsistente());}
}
