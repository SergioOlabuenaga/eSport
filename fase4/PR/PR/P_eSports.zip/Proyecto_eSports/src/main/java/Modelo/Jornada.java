package Modelo;

import javax.persistence.*;
import java.sql.Date;
import java.util.Objects;

@Entity
public class Jornada {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_JORNADA")
    private int idJornada;
    @Basic
    @Column(name = "FECHA")
    private Date fecha;

    public int getIdJornada() {
        return idJornada;
    }

    public void setIdJornada(int idJornada) {
        this.idJornada = idJornada;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Jornada jornada = (Jornada) o;
        return idJornada == jornada.idJornada && Objects.equals(fecha, jornada.fecha);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idJornada, fecha);
    }
}
