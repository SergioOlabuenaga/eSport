package Views.Read;

import Controlador.Main;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VerUsuario {
    private JLabel lTitulo;
    public JPanel jVerUsuarios;
    private JTextArea taVerUsuarios;
    private JButton bSalir;
    private JPanel jFoto;
    private JLabel lFoto;


    public VerUsuario() {
        taVerUsuarios.setText(Main.consultarUsuarios());

        bSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.cerrarVentana();
                Main.ventanaAdministrador();
            }
        });
    }
}
