package Views.Delete;

import Controlador.Main;
import Modelo.Equipo;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class BorrarEquipo {
    public JPanel jEliminarEquipo;
    private JLabel lTitulo;
    private JPanel jContenido;
    private JPanel jBotones;
    private JButton bAceptar;
    private JButton bSalir;
    private JComboBox cbEquipo;
    private JLabel jlEquipo;

    public BorrarEquipo() {
        ArrayList<Equipo> Equipo = Main.verNombreEquipos();
        for (Equipo equ : Equipo) {
            cbEquipo.addItem(equ);
        }

        bAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.borrarEquipo((Equipo) cbEquipo.getSelectedItem());
                Main.cerrarVentana();
                Main.ventanaEliminarEquipo();
            }
        });
        bSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.cerrarVentana();
                Main.ventanaAdministrador();
            }
        });


    }
}
