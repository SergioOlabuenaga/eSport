package Views.Login;

import Controlador.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaAdministrador {
    private JLabel lTitulo;
    private JMenu jmJornadas;
    private JMenuItem jmiGenerarJornada;
    private JMenu jmClasificacion;
    private JMenu jmDueño;
    private JMenu jmJugador;
    private JMenu jmEquipo;
    private JMenu jmUsuario;
    private JMenu jmCuenta;
    private JMenuItem jmiCerrarSesion;
    private JMenuItem jmiActualizarJornada;
    private JMenuItem jmiVerJornada;
    private JMenuItem jmiCrearDueño;
    private JMenuItem jmiModificarDueño;
    private JMenuItem jmiEliminarDueño;
    private JMenuItem jmiVerDueño;
    private JMenuItem jmiCrearJugador;
    private JMenuItem jmiModificarJugador;
    private JMenuItem jmiEliminarJugador;
    private JMenuItem jmiVerJugador;
    private JMenuItem jmiCrearEquipo;
    private JMenuItem jmiModificarEquipo;
    private JMenuItem jmiEliminarEquipo;
    private JMenuItem jmiVerEquipo;
    private JMenuItem jmiCrearUsuario;
    private JMenuItem jmiModificarUsuario;
    private JMenuItem jmiEliminarUsuario;
    private JMenuItem jmiVerUsuario;
    public JPanel jAdministrador;
    private JMenuItem jmiVerClasificacion;
    private JPanel jPrincipal;
    private JMenuBar jmbMenu;
    private JPanel jFoto;
    private JLabel jlBienvenida;
    private JMenu jmAsistente;
    private JMenuItem jmiCrearAsistente;
    private JMenuItem jmiModificarAsistente;
    private JMenuItem jmiEliminarAsistente;
    private JMenuItem jmiVerAsistente;
    private JMenu jmEntrenador;
    private JMenuItem jmiCrearEntrenador;
    private JMenuItem jmiModificarEntrenador;
    private JMenuItem jmiEliminarEntrenador;
    private JMenuItem jmiVerEntrenador;

    public VistaAdministrador() {

        jlBienvenida.setText("Bienvenido, " + Main.usuario);

        jmiVerClasificacion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver clasificación */
                Main.cerrarVentana();
                Main.ventanaVerClasificacion();
            }
        });

        jmiCrearDueño.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver crear dueño */
                Main.cerrarVentana();
                Main.ventanaCrearDueño();
            }
        });

        jmiModificarDueño.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver modificar dueño */
                Main.cerrarVentana();
                Main.ventanaModificarDueño();
            }
        });

        jmiEliminarDueño.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver eliminar dueño */
                Main.cerrarVentana();
                Main.ventanaEliminarDueño();
            }
        });

        jmiVerDueño.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver dueño */
                Main.cerrarVentana();
                Main.ventanaVerDueno();
            }
        });

        jmiCrearJugador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en crear jugador */
                Main.cerrarVentana();
                Main.ventanaCrearJugador();
            }
        });


        jmiModificarJugador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en modificar jugador */
                Main.cerrarVentana();
                Main.ventanaModificarJugador();
            }
        });


        jmiEliminarJugador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en eliminar jugador */
                Main.cerrarVentana();
                Main.ventanaEliminarJugador();
            }
        });


        jmiVerJugador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver jugador */
                Main.cerrarVentana();
                Main.ventanaVerJugadores();
            }
        });


        jmiCrearEquipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en crear equipo */
                Main.cerrarVentana();
                Main.ventanaCrearEquipo();
            }
        });


        jmiModificarEquipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en modificar equipo */
                Main.cerrarVentana();
                Main.ventanaModificarEquipo();
            }
        });

        jmiEliminarEquipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en eliminar equipo */
                Main.cerrarVentana();
                Main.ventanaEliminarEquipo();
            }
        });

        jmiVerEquipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver equipo */
                Main.cerrarVentana();
                Main.ventanaVerEquipo();
            }
        });

        jmiCrearUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en crear usuario */
                Main.cerrarVentana();
                Main.ventanaCrearUsuario();
            }
        });

        jmiModificarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en modificar usuario */
                Main.cerrarVentana();
                Main.ventanaModificarUsuario();
            }
        });

        jmiEliminarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en eliminar usuario */
                Main.cerrarVentana();
                Main.ventanaEliminarUsuario();
            }
        });

        jmiVerUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver usuario */
                Main.cerrarVentana();
                Main.ventanaVerUsuarios();
            }
        });

        jmiCerrarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en cerrar sesión */
                Main.cerrarVentana();
                Main.ventanaPrincipal();
            }
        });

        jmiGenerarJornada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en generar jornada */
                Main.generarJornada();
            }
        });

        jmiActualizarJornada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en modificar jornada */
                Main.cerrarVentana();
                Main.ventanaModificarJornada();
            }
        });

        jmiVerJornada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver jornada */
                Main.cerrarVentana();
                Main.ventanaVerJornada();
            }
        });

        jmiCrearAsistente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en crear asistente */
                Main.cerrarVentana();
                Main.ventanaCrearAsistente();
            }
        });

        jmiVerAsistente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver asistente */
                Main.cerrarVentana();
                Main.ventanaVerAsistente();
            }
        });


        jmiModificarAsistente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en modificar asistente */
                Main.cerrarVentana();
                Main.ventanaModificarAsistente();
            }
        });

        jmiModificarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en modificar usuario */
                Main.cerrarVentana();
                Main.ventanaModificarUsuario();
            }
        });

        jmiEliminarAsistente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en eliminar asistente */
                Main.cerrarVentana();
                Main.ventanaEliminarAsistente();
            }
        });

        jmiCrearEntrenador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en crear entrenador */
                Main.cerrarVentana();
                Main.ventanaCrearEntrenador();
            }
        });

        jmiEliminarEntrenador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en eliminar entrenador */
                Main.cerrarVentana();
                Main.ventanaEliminarEntrenador();
            }
        });

        jmiModificarEntrenador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en modificar entrenador */
                Main.cerrarVentana();
                Main.ventanaModificarEntrenador();
            }
        });

        jmiVerEntrenador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Accion al hacer click en ver entrenador */
                Main.cerrarVentana();
                Main.ventanaVerEntrenador();
            }
        });
    }

    public static void Bienvenido(String usuario) {

    }
}
