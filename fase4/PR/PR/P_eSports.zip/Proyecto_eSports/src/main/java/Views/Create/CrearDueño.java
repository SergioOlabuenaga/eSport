package Views.Create;

import Controlador.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CrearDueño {
    private JLabel lTitulo;
    public JPanel jCrearDueño;
    private JTextField tfNombre;
    private JTextField tfTelefono;
    private JTextField tfEmpresa;
    private JLabel lNombre;
    private JLabel lTelefono;
    private JLabel lEmpresa;
    private JButton bCrear;
    private JButton bSalir;
    private JPanel jBotones;
    private JPanel jContenido;

    public CrearDueño() {
        bCrear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.generarDueño(tfNombre.getText(),tfTelefono.getText(),tfEmpresa.getText());
            }
        });
        bSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.cerrarVentana();
                Main.ventanaAdministrador();
            }
        });
    }



}
