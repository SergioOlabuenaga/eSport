package Modelo;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Asistente {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_ASISTENTE")
    private int idAsistente;
    @Basic
    @Column(name = "NOMBRE")
    private String nombre;
    @Basic
    @Column(name = "TELEFONO")
    private String telefono;
    @Basic
    @Column(name = "DESCRIPCION_FUNCION")
    private String descripcionFuncion;

    public int getIdAsistente() {
        return idAsistente;
    }

    public void setIdAsistente(int idAsistente) {
        this.idAsistente = idAsistente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDescripcionFuncion() {
        return descripcionFuncion;
    }

    public void setDescripcionFuncion(String descripcionFuncion) {
        this.descripcionFuncion = descripcionFuncion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Asistente asistente = (Asistente) o;
        return idAsistente == asistente.idAsistente && Objects.equals(nombre, asistente.nombre) && Objects.equals(telefono, asistente.telefono) && Objects.equals(descripcionFuncion, asistente.descripcionFuncion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAsistente, nombre, telefono, descripcionFuncion);
    }

    @Override
    public String toString() {
        return nombre;
    }
}
