package Views.Update;

import Controlador.Main;
import Modelo.Dueno;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ModificarDueño {
    public JPanel jModificarDueño;
    private JLabel jlTitulo;
    private JLabel jlNombre;
    private JPanel jpContenido;
    private JPanel jpBotones;
    private JButton bAceptar;
    private JButton bSalir;
    private JComboBox cbDueno;
    private JTextField tfTlf;
    private JTextField tfEmpresa;

    public ModificarDueño(){
        ArrayList<Dueno> Dueno = Main.verNombreDuenos();
        for (Dueno due : Dueno) {
            cbDueno.addItem(due);
        }

        bAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.actializarDueno(cbDueno.getSelectedItem(),tfTlf.getText(),tfEmpresa.getText());
            }
        });
        bSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.cerrarVentana();
                Main.ventanaAdministrador();
            }
        });
        cbDueno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfTlf.setText(Main.infoDueno(cbDueno.getSelectedItem()).getTelefono());
                tfEmpresa.setText(Main.infoDueno(cbDueno.getSelectedItem()).getNombreEmpresa());
            }
        });
    }

}
