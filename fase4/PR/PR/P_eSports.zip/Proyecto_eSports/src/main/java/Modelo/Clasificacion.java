package Modelo;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Clasificacion {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID_CLASIFICACION")
    private int idClasificacion;
    @Basic
    @Column(name = "ID_EQUIPO")
    private int idEquipo;
    @Basic
    @Column(name = "PUNTOS")
    private int puntos;
    @Basic
    @Column(name = "TEMPORADA")
    private int temporada;

    public int getIdClasificacion() {
        return idClasificacion;
    }

    public void setIdClasificacion(int idClasificacion) {
        this.idClasificacion = idClasificacion;
    }

    public int getIdEquipo() {
        return idEquipo;
    }

    public void setIdEquipo(int idEquipo) {
        this.idEquipo = idEquipo;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public int getTemporada() {
        return temporada;
    }

    public void setTemporada(int temporada) {
        this.temporada = temporada;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Clasificacion that = (Clasificacion) o;
        return idClasificacion == that.idClasificacion && Objects.equals(idEquipo, that.idEquipo) && Objects.equals(puntos, that.puntos) && Objects.equals(temporada, that.temporada);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idClasificacion, idEquipo, puntos, temporada);
    }
}
