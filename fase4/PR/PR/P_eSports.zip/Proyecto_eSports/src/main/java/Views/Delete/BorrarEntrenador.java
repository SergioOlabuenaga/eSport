package Views.Delete;

import Controlador.Main;
import Modelo.Entrenador;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class BorrarEntrenador {
    public JPanel jBorrarEntrenador;
    private JLabel jlTitulo;
    private JButton bAceptar;
    private JButton bSalir;
    private JPanel jBotones;
    private JPanel jContenido;
    private JLabel jlNombre;
    private JComboBox cbEntrenador;

    public BorrarEntrenador() {
        ArrayList<Entrenador> Entrenador = Main.verNombreEntrenadores();
        for (Entrenador entre : Entrenador) {
            cbEntrenador.addItem(entre);
        }

        bSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.cerrarVentana();
                Main.ventanaAdministrador();
            }
        });
        bAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.borrarEntrenador(cbEntrenador.getSelectedItem());
                Main.cerrarVentana();
                Main.ventanaEliminarEntrenador();
            }
        });
    }
}
